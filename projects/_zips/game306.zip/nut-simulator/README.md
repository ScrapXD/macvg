#nut simulator
thrilling clicker game with nuts
<br>
play it here!!
<br>
https://nutsimulator.github.io
